

<?php 

class UserModeL extends CI_Model

{


    public function Update_User_Data($user_id, $data){
        $this->db->set($data);
        $this->db->where('id', $user_id);
        $this->db->update(['users']);

                if( $this->db->affected_rows()> 0)
                    return true;


                    else

                    return false;

                }
    public function Check_Old_Password($user_id, $old_password){

        return $this->db->where('user_id',$user_id)->where('password',$old_password)
        ->get('users')->row();
    }

    public function updateNewPassword($id,$data){
        $this->db->set($data)
        ->where('user_id',$id)
        ->update('users');

    }
}


?>
