<?php 

class Queries extends CI_Model{
    public function login_user($username,$password){
        return $this->db->where('username',$username)->where('password',$password)
        ->get('users')->row();
    }
    public function getUserRole(){
        $query = $this->db->where(['role_name'=> 'Employee']) 
        ->get('user_role');
        if($query->num_rows() > 0){
           return $query->row()->id;
   
           }
           
    }
    public function get_employee_num_rows(){
        $this->db->select(['users.user_id', 'users.name','users.username', 'user_role.role_name']);
        $this->db->from('users');
        $this->db->join('user_role','user_role.id =users.user_role_id');
        $this->db->where(['users.user_role_id' => '2']);
        $query =$this->db->get();
        return $query->num_rows();
    }
  
    public function addEmployee($data){
        return $this->db->insert('users',$data);
    }
    public function getAllUsers(){
        $this->db->select(['users.user_id','users.name','users.username', 'users.password',
        'user_role.role_name']);
        $this->db->from('users');
        $this->db->join('user_role','user_role.id=users.user_role_id ');
        $query = $this->db->get();
        return $query->result();

    }

    public function getEmployeeRecords($employee_id){
        $query = $this->db->where(['user_id'=> $employee_id])
                            ->get('users');

                if($query->num_rows()> 0){
                    return $query->row();
                }


    }

    public function insertEmpPersonalDetails($data){
        return $this->db->insert('emp_personal_details', $data);
    }


    public function getEmpPersonalDetails($employee_id){
    $query  =$this->db->where(['user_id'=>$employee_id])->get('emp_personal_details');


    if($query->num_rows()> 0){
        return $query->row();
    }


    }
    public function insertEmpContactDetails($data){

    return $this->db->insert('emp_contact_details', $data);
    }

    public function getEmpContactDetails($employee_id){
        $query  =$this->db->where(['user_id'=>$employee_id])
        ->get('emp_contact_details');
    
    
        if($query->num_rows()> 0){
            return $query->row();
        }
    
    
        }


        public function insertEmpEmploymentDetails($data){

            return $this->db->insert('employment_details', $data);
            }


        public function getEmployeeDetails($employee_id){
            $query = $this->db->where(['user_id'=> $employee_id])
                            ->get('employment_details');
            if($query->num_rows() >0){

                return $query->row();


            }



        }
        public function insertEmpQualificationDetails($data){

            return $this->db->insert('emp_qualification', $data);
            }


        public function getQualificationDetails($employee_id){
            $query = $this->db->where(['user_id'=> $employee_id])
                            ->get('emp_qualification');
            if($query->num_rows() >0){

                return $query->row();


            }
    }

    public function insertMedicalformDetails($data){

        return $this->db->insert('medical_form_details', $data);
        }


    public function getMedicalformDetails($employee_id){
        $query = $this->db->where(['user_id'=> $employee_id])
                        ->get('medical_form_details');
        if($query->num_rows() >0){

            return $query->row();


        }
    }

        public function insertMessages($data){

            return $this->db->insert('messages', $data);
            }
           
    
            public function getAllMessages($employee_id){
                return $this->db->where(['user_id'=> $employee_id])
                ->get('messages')->result();
                
            }
            
        


        //  Leave Module 
            public function insertLeaveDetails($data){

                return $this->db->insert('leave_system', $data);
                }
        
        
            public function getLeaveDetails($employee_id){
                return $this->db->where(['user_id'=> $employee_id])
                ->get('leave_system')->result();
                
            }
// Leave Module 
//  Bank Account Details 
public function insertBankAccount($data){

    return $this->db->insert('account_details', $data);
    }



    public function getAllBankDetails(){
        return $this->db->get('account_details')->result();
    }
    public function getBankDet($employee_id){
        $query = $this->db->where(['user_id'=> $employee_id])
                        ->get('account_details');
        if($query->num_rows() >0){

            return $query->row();


        }
// end of bank details okrruuuuu

    }




public function insertLeaveData($data){
    $this->db->insert('leave_system',$data);
}

public function getAllRequest(){
    return $this->db->get('leave_system')->result();
}

public function approveRequest($id){

    $data=array(
        'status'=>2,
        'approved_date'=>date("Y-m-d"),
    );

    $this->db->set($data)
    ->where('id',$id)
    ->update('leave_system');
}

public function rejectRequest($id){

    $data=array(
        'status'=>3,
        'approved_date'=>date("Y-m-d"),
    );

    $this->db->set($data)
    ->where('id',$id)
    ->update('leave_system');
}



public function insertMessagesData($data){
    $this->db->insert('messages',$data);
}

public function getAllMsg(){
    return $this->db->get('messages')->result();
}




public function insertUploadedFiles($data){
    $this->db->insert('messages',$data);
}

public function getAllUploads(){
    return $this->db->get('messages')->result();
}



            public function deleteEmp($userid)
            {
            $this->db->delete('users',['user_id'=> $userid]);
            $this->db->delete('emp_personal_details',['user_id'=> $userid]);
            $this->db->delete('emp_contact_details',['user_id'=> $userid]);
            $this->db->delete('emp_qualification',['user_id'=> $userid]);
            $this->db->delete('account_details',['user_id'=> $userid]);
            $this->db->delete('employment_details',['user_id'=> $userid]);
            $this->db->delete('leave_system',['user_id'=> $userid]);
            $this->db->delete('medical_form_details',['user_id'=> $userid]);
            $this->db->delete('messages',['user_id'=> $userid]);
            $this->db->delete('upload_documents',['user_id'=> $userid]);
            $this->db->delete('medical_form_details',['user_id'=> $userid]);
           
            }  
            
public function getDocumentType(){
    return $this->db->get('document_type')->result();
}

public function insertDocuments($data){
    return $this->db->insert('upload_documents',$data);
}

public function getDocuments($id){
    $this->db->join('document_type','document_type.id=upload_documents.document_type');
    $this->db->where('upload_documents.user_id',$id);
    return $this->db->get('upload_documents')->result();
}

public function updateResponse($data,$id){
    $this->db->set($data)
    ->where('id',$id)
    ->update('messages');
    }

  
}








?>