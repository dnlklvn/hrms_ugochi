<?php
class Employee extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('Queries');
        $this->load->model('UserModeL');
        if(!$this->session->userdata('loggedIn')){
            return redirect('login');
        }

      }

    public function index(){
        

    }
    public function createEmployee(){
    
        $result = $this->Queries->getUserRole();
        
        $this->load->view('createEmployee',['result'=>$result]);
    }
    public function insertEmployee(){
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required|valid_email|is_unique[users.username]');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('user_role_id', 'User Role', 'required');
        $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
        
        if ($this->form_validation->run())
        {
           $data= $this->input->post();
         
           $this->load->model('Queries');

         
           if($this->Queries->addEmployee($data)){

            $this->session->set_flashdata('employee_add','Employee Added Succesfully');



           }else{
                  
            $this->session->set_flashdata('employee_add','Failed to add Employee');


           }

           return redirect('dashboard');


        }
        else{
            $this->createEmployee();
        }

    }
    public function empPersonalDetails($employee_id){
    
        $result = $this->Queries->getEmployeeRecords($employee_id);
        $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
        $records = $this->Queries->getEmpPersonalDetails($employee_id);
        $profile_pic = $this->Queries->getEmpPersonalDetails($employee_id);
        $this->load->view('empPersonalDetails',['result' => $result, 'records'=> $records,'user_identity' => $user_identity ,'profile_pic' => $profile_pic]);
    }

    public function addPersonalDetails($employee_id){
        $config = [
            'upload_path' => './uploads',
                'allowed_types' =>  'gif|jpg|png|jpeg'
 
        ];
       


$this->load->library('upload',$config);

        $this->form_validation->set_rules('first_name', 'First Name', 'required');
        $this->form_validation->set_rules('middle_name', 'Middle Name', 'required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'required');
        $this->form_validation->set_rules('username', 'UserName', 'required|valid_email[users.username]');
        $this->form_validation->set_rules('gender', 'Gender', 'required');
        $this->form_validation->set_rules('nationality', 'Nationality', 'required');
        $this->form_validation->set_rules('marital_status', 'Marital Status', 'required');
        $this->form_validation->set_rules('dob', 'Date of Birth', 'required');
       // $this->form_validation->set_rules('avatar', 'Profile Image', 'required');
        $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
        

        if($this->form_validation->run() && $this->upload->do_upload(
        'avatar')){

           $data = $this->input->post();
           $upload_info =$this->upload->data();
          $path = base_url("uploads/". $upload_info['raw_name'].
          $upload_info['file_ext']);


          $data['avatar'] = $path;
          
          $this->load->model('Queries');
          if($this->Queries-> insertEmpPersonalDetails($data)){
           

            $this->session->set_flashdata('employee_add', 'Employee Successfully Added');

          }else{


            $this->session->set_flashdata('employee_add', 'Failed to Add Employee');
          }

return redirect('dashboard');

      


        }
        else{
            $upload_error = $this->upload->display_errors();
             $this->empPersonalDetails($employee_id);

            //echo validation_errors();
        }
    }
    public function empContactDetails($employee_id){
        $this->load->model('Queries');
        $result = $this->Queries->getEmployeeRecords($employee_id);
   
        $records = $this->Queries->getEmpContactDetails($employee_id);
        $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
        $profile_pic = $this->Queries->getEmpPersonalDetails($employee_id);
        $this->load->view('empContactDetails', ['result' => $result, 'records' => $records, 'profile_pic' => $profile_pic, 'user_identity' => $user_identity ]);

    }

    public function addContactDetails($employee_id){
        $this->form_validation->set_rules('home_address', 'Home Address', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('state', 'State Of Origin', 'required');
        $this->form_validation->set_rules('zip_code', 'Zip Code', 'required');
        $this->form_validation->set_rules('country', 'Country', 'required');
        $this->form_validation->set_rules('mobile_no_1', 'Mobile Number 1', 'required');
        $this->form_validation->set_rules('mobile_no_2', 'Mobile Number 1', 'required');
        $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
       
       
       
       
        if ($this->form_validation->run())
        {
            $data = $this->input->post();

            $this->load->model('Queries');


            if($this->Queries->insertEmpContactDetails($data)){
                $this->session->set_flashdata('employee_add', 'Employee Contact Details Successfully Added');
                
            }
            else{
                $this->session->set_flashdata('employee_add', 'Failed to Add Employee Contact Details ');
            }
            return redirect('dashboard');
        }


   

        else{
          $this-> empContactDetails($employee_id);


            }

    }
    public function empEmploymentDetails($employee_id){
       
  
      
        $this->load->model('Queries');
        $result = $this->Queries->getEmployeeRecords($employee_id);
        $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
        $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
        $records = $this->Queries->getEmployeeDetails($employee_id);
        $this->load->view('empEmploymentDetails',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic, 'user_identity' => $user_identity ]);
    
    }


    public function addEmploymentDetails($employee_id){
        $this->form_validation->set_rules('category', 'Category', 'required');
        $this->form_validation->set_rules('department', 'department', 'required');
        $this->form_validation->set_rules('post', 'Post', 'required');
        $this->form_validation->set_rules('date_of_resumption', 'Date of Resumption', 'required');
       
        $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
       
       if($this->form_validation->run())
       
       {
            $data =$this->input->post();
            $this->load->model('Queries');
     

            if($this->Queries->insertEmpEmploymentDetails($data)){
                $this->session->set_flashdata('employee_add', 'Employee Contact Details Successfully Added');
                
            }
            else{
                $this->session->set_flashdata('employee_add', 'Failed to Add Employee Contact Details ');
            }
            return redirect('dashboard');
        
       }
    
  
    
    //echo validation_errors();
$this->empEmploymentDetails($employee_id);



    }

    // this is how it starts 
    public function empQualificationDetails($employee_id){
        $this->load->model('Queries');
        $result = $this->Queries->getEmployeeRecords($employee_id);
        $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
        $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
        $records = $this->Queries->getQualificationDetails($employee_id);
        $this->load->view('empQualificationDetails',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic, 'user_identity' => $user_identity ]);
    }
    
    public function addQualificationDetails($employee_id){
        $this->form_validation->set_rules('qualification_1', 'Qualification Level 1', 'required');
        $this->form_validation->set_rules('qualification_2', 'Qualification Level 2', 'required');
        $this->form_validation->set_rules('qualification_3', 'Qualification Level 3', 'required');
        $this->form_validation->set_rules('qualification_4', 'Qualification Level 4', 'required');
        $this->form_validation->set_rules('qualification_5', 'Qualification Level 5', 'required');
        $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
       
       if($this->form_validation->run())
       
       {
            $data =$this->input->post();
            $this->load->model('Queries');
     

            if($this->Queries->insertEmpQualificationDetails($data)){
                $this->session->set_flashdata('employee_add', 'Employee Contact Details Successfully Added');
                
            }
            else{
                $this->session->set_flashdata('employee_add', 'Failed to Add Employee Contact Details ');
            }
            return redirect('dashboard');


        
}

     $this->empQualificationDetails($employee_id);
    }
  // this is how it ends



   


    // this is how it starts 
    public function empMedicalDetails($employee_id){
        $this->load->model('Queries');
        $result = $this->Queries->getEmployeeRecords($employee_id);
        $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
        $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
        $records = $this->Queries->getmedicalformDetails($employee_id);
        $this->load->view('empMedicalDetails',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic, 'user_identity' => $user_identity ]);
    }
    
    public function addMedicalformDetails($employee_id){
        $this->form_validation->set_rules('health_id', 'Health ID', 'required');
        $this->form_validation->set_rules('full_name', 'Full Name Level 2', 'required');
        $this->form_validation->set_rules('department', 'Department', 'required');
        $this->form_validation->set_rules('mobile_no', 'Mobile Number', 'required');
        $this->form_validation->set_rules('email_address', 'Email Address', 'required|valid_email');
        $this->form_validation->set_rules('home_address', 'Home Address', 'required');
        $this->form_validation->set_rules('guardian_name', 'Guardian Name ', 'required');
        $this->form_validation->set_rules('guardian_number', 'Guardian Number', 'required');
        $this->form_validation->set_rules('genotype', 'Genotype', 'required');
        $this->form_validation->set_rules('blood_group', 'Blood Group', 'required');
        $this->form_validation->set_rules('health_complications', 'Health Complications', 'required');
       
        $this->form_validation->set_rules('eye_test', 'Guardian Name ', 'required');
        $this->form_validation->set_rules('urine_test', 'Guardian Number', 'required');
        $this->form_validation->set_rules('ecg', 'Genotype', 'required');
        $this->form_validation->set_rules('height', 'Blood Group', 'required');
        $this->form_validation->set_rules('weight', 'Genotype', 'required');
        $this->form_validation->set_rules('disclaimer', 'Blood Group', 'required');
        $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
       
       if($this->form_validation->run())
       
       {
            $data =$this->input->post();
            $this->load->model('Queries');
     

            if($this->Queries->insertMedicalformDetails($data)){
                $this->session->set_flashdata('employee_add', 'Employee Medical Details Successfully Added');
                
            }
            else{
                $this->session->set_flashdata('employee_add', 'Failed to Add Employee Medical Details ');
            }
            return redirect('dashboard');
        
}
$this->empMedicalDetails($employee_id);
   
    }

   // this is how it starts 
//    public function sendMessages($employee_id){
//     $this->load->model('Queries');
//     $result = $this->Queries->getEmployeeRecords($employee_id);
   
//     $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
//     $records = $this->Queries->getMessages($employee_id);
//     $this->load->view('sendMessages',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic]);
// }

// public function addMessages($employee_id){
//     $this->form_validation->set_rules('message', 'Message', 'required');
//     $this->form_validation->set_rules('date_sent', 'Date Sent', 'required');
//     $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
   
//    if($this->form_validation->run())
   
//    {
//         $data =$this->input->post();
//         $this->load->model('Queries');
 

//         if($this->Queries->insertMessages($data)){
//             $this->session->set_flashdata('employee_add', 'Message Sent');
            
//         }
//         else{
//             $this->session->set_flashdata('employee_add', 'Failed to Send Message ');
//         }
//         return redirect('sendMessages');
    
// }
//                     $this->sendMessages($employee_id);

//                     }

                   
    
   // this is how it starts 
   public function leave_request($employee_id){
    $this->load->model('Queries');
    $result = $this->Queries->getEmployeeRecords($employee_id);
    $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
    $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
    $records = $this->Queries->getLeaveDetails($employee_id);
    $this->load->view('leave_request',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic, 'user_identity' => $user_identity ]);
}

public function addLeaveRequests($employee_id){
    $this->form_validation->set_rules('full_name', 'Reason', 'required');
    $this->form_validation->set_rules('purpose', 'Reason', 'required');
    $this->form_validation->set_rules('date_to_start', 'Date Start', 'required');
    $this->form_validation->set_rules('date_to_end', 'Date End', 'required');
    $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
   
   if($this->form_validation->run())
   
   {
        $data =$this->input->post();
        $this->load->model('Queries');
        $insertData=array(

            'full_name'=>$this->input->post('full_name'),
            'purpose'=>$this->input->post('purpose'),
            'user_id'=>$this->session->userdata('loggedIn')['id'],
            'date_to_start'=>$this->input->post('date_to_start'),
            'date_to_end'=>$this->input->post('date_to_end'),
            'status'=>1,

        );
        $this->Queries->insertLeaveDetails($insertData);
        $this->session->set_flashdata('employee_add', 'Leave Applied For');
       

        redirect('employee/leave_request/'.$employee_id);
    
    }
}

    // $this->leave_request($employee_id);

    public function sendMessages($employee_id){
        $this->load->model('Queries');
        $result = $this->Queries->getEmployeeRecords($employee_id);
        $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
        $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
        $records = $this->Queries->getAllMessages($employee_id);
        $this->load->view('sendMessages',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic, 'user_identity'=>$user_identity]);
    }
    
    public function addMessages($employee_id){
        $this->form_validation->set_rules('message', 'Reason', 'required');
        $this->form_validation->set_rules('date_sent', 'Reason', 'required');
        
        $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
       
       if($this->form_validation->run())
       
       {
            $data =$this->input->post();
            $this->load->model('Queries');
            $insertData=array(
    
                'message'=>$this->input->post('message'),
                'date_sent'=>$this->input->post('date_sent'),
                'user_id'=>$this->session->userdata('loggedIn')['id'],
                'response_message'=>$this->input->post('response_message'),
                'recieved_date'=>$this->input->post('recieved_date'),
                
    
            );
            $this->Queries->insertMessages($insertData);
            $this->session->set_flashdata('employee_add', 'Leave Applied For');
           
    
            redirect('employee/sendMessages/'.$employee_id);
        
        }

}


                     
                              // Start Account Details for users
// this is how it starts 


                              // Start Account Details for users
// this is how it starts 
public function bank_account_details($employee_id){
    $this->load->model('Queries');
    $result = $this->Queries->getEmployeeRecords($employee_id);
    $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
    $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
    $records = $this->Queries->getBankDet($employee_id);
    $this->load->view('bank_account_details',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic, 'user_identity'=>$user_identity]);
}

public function addAccountDetails($employee_id){
    $this->form_validation->set_rules('account_name', 'Account Name', 'required');
    $this->form_validation->set_rules('sort_code', 'Sort Code', 'required');
    $this->form_validation->set_rules('account_number', 'Account Number', 'required');
    $this->form_validation->set_rules('bank_name', 'Bank Name', 'required');
    $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
   
   if($this->form_validation->run())
   
   {
        $data =$this->input->post();
        $this->load->model('Queries');
 

        if($this->Queries->insertBankAccount($data)){
            $this->session->set_flashdata('employee_add', 'Account Details Entered');
            
        }
        else{
            $this->session->set_flashdata('employee_add', 'Failed to Apply for Leave ');
        }
        return  $this->bank_account_details($employee_id);
    
}
                    $this->bank_account_details($employee_id);

                    }

                    // END Uploading documents
//Messages Sending and Receiving 

public function admin_leaveRequest(){
        
    $getRequest=$this->Queries->getAllRequest();
    $data=array(
        'records'=>$getRequest,
    );
    $this->load->view('admin_leaveRequest',$data);

    
}

public function approveRequest($id){

    $approve=$this->Queries->approveRequest($id);
    $this->session->set_flashdata('employee_add','Request approved successfully');
    redirect('admin/admin_leaveRequest');

    
}
public function rejectRequest($id){

    $reject=$this->Queries->rejectRequest($id);
    $this->session->set_flashdata('employee_add','Request rejected successfully');
    redirect('admin/admin_leaveRequest');
}

/// Ended
                    public function user_change_Password($employee_id){
                       
                                        $this->load->model('Queries');
                    $result = $this->Queries->getEmployeeRecords($employee_id);
                    $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
                    $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
                    $records = $this->Queries->getBankDet($employee_id);
                    $this->load->view('user_change_Password',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic, 'user_identity' => $user_identity]);
                 }

                    
///////////////Password thing 

public function change_password($employee_id){

    $this->form_validation->set_rules('old_password', 'Old Password', 'trim|required|min_length[4]|max_length[30]');
    $this->form_validation->set_rules('new_password', 'New Password', 'trim|required|min_length[8]|max_length[30]');
    $this->form_validation->set_rules('rpt_new_password', 'Repeat New Password', 'trim|required|matches[new_password]');
    
    $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');

    if($this->form_validation->run()){
    
        $old_password=$this->input->post('old_password');
        $verify=$this->UserModeL->Check_Old_Password($employee_id, $old_password);
        
        if($verify){
            $data = array(
                'password' => $this->input->post('new_password'),
                'update_date' => date('Y-m-d')
            );

            $this->UserModeL->updateNewPassword($employee_id,$data);
            
            $this->session->set_flashdata('employee_add', 'Password Changed Successfully');
            $this->user_change_Password($employee_id);
            
        }
        else{
          echo $this->session->set_flashdata('employee_add', 'Invalid Password');
            
            
        }
    }
    else{


        
        
    }
    $this->user_change_Password($employee_id);

}



                



                        
public function upload_documents($employee_id){
    $this->load->model('Queries');
    $result = $this->Queries->getEmployeeRecords($employee_id);
    $user_identity =$this->Queries->getEmpPersonalDetails($employee_id);
    $profil_pic =$this->Queries->getEmpPersonalDetails($employee_id);
    $records = $this->Queries->getAllUploads($employee_id);
    $document=$this->Queries->getDocumentType();
    $doc=$this->Queries->getDocuments($employee_id);

    $this->load->view('upload_documents',['result' => $result, 'records'=> $records, 'profil_pic'=>$profil_pic,'document_types'=>$document,'docs'=>$doc, 'user_identity' => $user_identity]);
}

public function addDocuments($employee_id){

    $config = array();
    $config['upload_path'] = './uploads/documents';
    $config['allowed_types'] = 'gif|jpg|png|pdf|doc|docx|jpeg';
    $config['max_size']      = '5000';
    $config['overwrite']     = FALSE;
    // $config['encrypt_name']=TRUE;

    $this->load->library('upload');
    $files = $_FILES;

    for($i=0; $i<count($this->input->post('id')); $i++){


        $time = date('Ymd').time().$i;
        $path=$files['userfile']['name'][$i];
        $newName=$time.".".pathinfo($path,PATHINFO_EXTENSION);
       
        
        $_FILES['userfile']['name']=$newName;
        $_FILES['userfile']['type']= $files['userfile']['type'][$i];
        $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
        $_FILES['userfile']['error']= $files['userfile']['error'][$i];
        $_FILES['userfile']['size']= $files['userfile']['size'][$i];
        $this->upload->initialize($config);
        $this->upload->do_upload();

        $data= array(
            'user_id'=>$employee_id,
            'document_type'=>$this->input->post('id')[$i],
            'name'=>$newName,
        );
        $this->Queries->insertDocuments($data);
       
       
    }

   if($this->form_validation->run())
   
   {

    

    
        $data =$this->input->post();
        $this->load->model('Queries');
 

        if($this->Queries->insertBankAccount($data)){
            $this->session->set_flashdata('employee_add', 'Account Details Entered');
            
        }
        else{
            $this->session->set_flashdata('employee_add', 'Failed to Apply for Leave ');
        }
        return  $this->upload_documents($employee_id);
    
}
                    $this->upload_documents($employee_id);

                    }



public function deleteEmployee(){
    $this->load->model('Queries');
    foreach($_POST['user_id'] as $userid){
        $this->Queries->deleteEmp($userid);
    }
    return redirect('dashboard');
}





}


                        

?>
