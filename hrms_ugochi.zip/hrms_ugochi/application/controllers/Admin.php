
<?php
class Admin extends CI_Controller{

    public function __construct(){

        parent::__construct();
        $this->load->model('Queries');

        if(!$this->session->userdata('loggedIn')){
            return redirect('login');
        }

        if($this->session->userdata('loggedIn') && $this->session->userdata('loggedIn')['roleID']>1){
            return redirect('employee/empPersonalDetails/'.$this->session->userdata('loggedIn')['id']);
        }


    }

    public function index(){

    }

    public function admin_leaveRequest(){
        
        $getRequest=$this->Queries->getAllRequest();
        $data=array(
            'records'=>$getRequest,
        );
        $this->load->view('admin_leaveRequest',$data);

        
    }

    public function approveRequest($id){

        $approve=$this->Queries->approveRequest($id);
        $this->session->set_flashdata('employee_add','Request approved successfully');
        redirect('admin/admin_leaveRequest');

        
    }
    public function rejectRequest($id){

        $reject=$this->Queries->rejectRequest($id);
        $this->session->set_flashdata('employee_add','Request rejected successfully');
        redirect('admin/admin_leaveRequest');
    }





















        public function admin_reply_messages(){
         
            $getRequest=$this->Queries->getAllMsg();
        $data=array(
            'records'=>$getRequest,
        );
        $this->load->view('admin_reply_messages',$data);

        
    
        }




     
        public function admin_view_account_details(){
        
            $getBankDetails=$this->Queries->getAllBankDetails();
            $data=array(
                'records'=>$getBankDetails,
            );
            $this->load->view('admin_view_account_details',$data);
    
            
        }







        
        public function admin_view_uploaded_documents(){
        
            $getUploads=$this->Queries->getAllUploads();
            $data=array(
                'records'=>$getUploads,
            );
            $this->load->view('admin_view_uploaded_documents');
    
            
        }




        
        public function admin_message_response($id){
            $data=array(
                'id'=>$id,
            );
           
            $this->load->view('admin_message_response',$data);
    
            
        }
        public function admin_response(){
            $data=array(
                'response_message'=>$this->input->post('response'),
                'recieved_date'=>date('Y-m-d')
            );
            $id=$this->input->post('id');
            $this->Queries->updateResponse($data,$id);
            
            $this->admin_reply_messages();
        }
    }

    ?>
