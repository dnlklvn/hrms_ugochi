<?php

class Login extends CI_Controller{

    


    public function index(){


        if($this->session->userdata('loggedIn') && $this->session->userdata('loggedIn')['roleID']>1){
            return redirect('employee/empPersonalDetails/'.$this->session->userdata('loggedIn')['id']);
        }
        elseif($this->session->userdata('loggedIn') && $this->session->userdata('loggedIn')['roleID']==1){
            return redirect('dashboard');
        }
        $this->load->view('login');
            
        
    }
     public function user_login(){

   
            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
            $this->form_validation->set_error_delimiters('<div class ="text-danger">', '</div>');
            
            if ($this->form_validation->run())
            {
                    $username = $this->input->post('username');
                    $password= $this->input->post('password');

                    $this->load->model('Queries');
                    
                    $user = $this->Queries->login_user($username, $password);
                if($user){

                    $sess=array(
                        'id'=>$user->user_id,
                        'username'=>$user->username,
                        'roleID'=>$user->user_role_id,
                    );

                    $this->session->set_userdata('loggedIn',$sess);
                    if($user->user_role_id==1){
                        return redirect('dashboard');
                    }
                    else{
                        return redirect('employee/empPersonalDetails/'.$user->user_id);
                    }
                    
                }
                else{
                   $this->session->set_flashdata('login_response','Invalid Username/Password');
                  return redirect('login'); 
                }
            }
            else
            {
                    $this->load->view('login');
        
            }
        }
        

        public function logout(){
            $this->session->sess_destroy();
            redirect('login');
        }
     }



?>