<?php

class Dashboard extends CI_Controller{

    
public function index(){
   
    if(!$this->session->userdata('loggedIn')){
        return redirect('login');
    }
    
     else{
         $this->load->model('Queries');
         $result = $this->Queries->getAllUsers();
     

        $this->load->view('Dashboard',['result' => $result]);
    }

  

}
}
?>