<?php 

include('includes/header.php');
include('includes/navbar.php');

?>

    
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
     

            <!-- Modal -->


            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Ugochi</span>
                
                <img class="img-profile rounded-circle" src="<?php echo base_url('resources/img/avatar04.png'); ?>">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
<?php echo form_open("employee/insertEmployee", ['class' => 'form-horizontal']); ?>
          <!-- Page Heading -->
         <!-- Button trigger modal -->
         <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add New Employee</h1>
            <br>
              <?php echo anchor("dashboard", 'Dashboard', ['class'=> 'btn btn-warning btn-sm']); ?>
          </div>
          
            <div class ="row">
        <div class= "col-lg-6">
                <div class = "form-group">
                <label for ="inputEmail" class ="col-lg-2 control-label">Name</label>
                    <div class ="col-lg-10">
   <?php echo form_input(['name'=> 'name', 'class' =>'form-control', 'placeholder' => 'Enter Name', 'value' =>set_value('name')]); ?>
                            
                          </div>
                        
                    </div>
                    </div>
                    </div>
                    <div class ="col-lg-6">
    <?php echo form_error('name', '<div class = "text-danger">', '</div>'); ?>

</div>

<div class ="row">
<div class= "col-lg-6">
<div class = "form-group">
<label for ="inputEmail" class ="col-lg-6 control-label">Username</label>
<div class ="col-lg-10">

            <?php echo form_input(['name'=> 'username', 'class' =>'form-control', 'placeholder' => 'Enter Username', 'value' =>set_value('username')]); ?>
                            
                          </div>
                        
</div>
</div>
</div>
<div class ="col-lg-6">
<?php echo form_error('username', '<div class = "text-danger">', '</div>'); ?>

</div>

    <div class ="row">
                <div class= "col-lg-6">
                    <div class = "form-group">
                    <label for ="inputEmail" class ="col-lg-6 control-label">Password</label>
            <div class ="col-lg-10">

            <?php echo form_password(['name'=> 'password', 'class' =>'form-control', 'placeholder' => 'Enter Password',  'value' =>set_value('name')]); ?>
                            
                          </div>
                        
</div>
</div>
</div>
<div class ="col-lg-6">
<?php echo form_error('password', '<div class = "text-danger">', '</div>'); ?>

</div>

<div class ="row">
<div class= "col-lg-6">
<div class = "form-group">
<label for ="inputEmail" class ="col-lg-6 control-label">User Role</label>
<div class ="col-lg-10">

            <select class ="form-control" name="user_role_id">
            <option></option>
            <option value = <?php echo $result; ?>>Employee </option>

            </select>
                        
</div>
</div>
</div>
<div class ="col-lg-6">
<?php echo form_error('user_role_id', '<div class = "text-danger">', '</div>'); ?>

</div>



</div>
                          <?php echo form_submit(['value'=> 'Submit', 'class' =>'btn btn-success btn-user btn-sm']); ?>
                          <?php echo form_reset(['value'=> 'Reset', 'class' =>'btn btn-primary btn-user btn-sm']); ?>
                         
                        <?php echo form_close(); ?>









</div>

</div>

</div>
</div>





















</div>

        </div>



            <?php 
  include('includes/footer.php');
include('includes/script.php');


?>
  