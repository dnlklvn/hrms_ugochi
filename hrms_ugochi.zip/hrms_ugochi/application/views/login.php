<?php include('includes/header.php'); ?>



    <body class="bg-gradient-primary">

        <div class="container">
     
        <?php echo form_open("login/user_login", ['class' =>'user']); ?>
          <!-- Outer Row -->
          <div class="row justify-content-center">
          <img src="<?php echo base_url('resources/img//FUTO_logo.png" alt="Logo'); ?>" >
            <div class="col-xl-10 col-lg-12 col-md-9">
      
              <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
           

                  <!-- Nested Row within Card Body -->
                  <div class="row">
                  
                    <div class="col-lg-6 d-none d-lg-block "></div>
                   
                    <div class="col-lg-6">
                      
                      <div class="p-5">
                        <div class="text-center">
                          <h1 class="h4 text-gray-900 mb-4">Admin and Employee Login</h1>
                          <?php echo form_error('username', '<div class ="text-danger">', '</div>'); ?>
                          <?php echo form_error('password', '<div class ="text-danger">', '</div>'); ?>
                          <?php if($error =$this->session->flashdata('login_response')): ?>
                  <div class ="row">
                    <div class ="col">
                      <div class ="alert-dismissable alert-danger">
          <?php echo $error; ?>
            </div>
        </div>
            </div>
<?php endif; ?>
                        </div>
                       
                          <div class="form-group">
            <?php echo form_input(['name'=> 'username', 'class' =>'form-control', 'placeholder' => 'Enter Email Address','value' =>set_value('username')]); ?>
                            
                          </div>
                        
                          
                          <div class="form-group">
                           
                              
                              <?php echo form_password(['name'=> 'password', 'class' =>'form-control', 'placeholder' => 'Enter Password' ]); ?>
                              
                          
                         
                          </div>
                          <?php echo form_submit(['value'=> 'Submit', 'class' =>'btn btn-success btn-user btn-block']); ?>
                          <?php echo form_reset(['value'=> 'Reset', 'class' =>'btn btn-primary btn-user btn-block']); ?>
                         
                        <?php echo form_close(); ?>
                     
                       
                      </div>
                    </div>
                  </div>
                </div>
              </div>
      
            </div>
      
          </div>
      
        </div>
        </div>
        <!-- /.container-fluid -->
       
 

      </div>
      <!-- End of Main Content -->

      <?php include('includes/footer.php'); ?>
<?php include('includes/script.php'); ?>
