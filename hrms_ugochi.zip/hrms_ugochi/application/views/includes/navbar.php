<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo base_url("employee/empPersonalDetails/{$result->user_id}"); ?>">
  <div class="simple">
  <img class="brand-image img-circle elevation-3" src="<?php echo base_url('resources/img//FUTO_logo.png" alt="Logo'); ?>" >
  </div>
  
  <div class="sidebar-brand-text mx-3" class="brand-image img-circle elevation-3"
           style="opacity: .8">HRM Systems</div>
</a>
<?php else:?>
  <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo base_url ("dashboard"); ?>">
  <div class="simple">
  <img class="brand-image img-circle elevation-3" src="<?php echo base_url('resources/img//FUTO_logo.png" alt="Logo'); ?>" >
  </div>
  
  <div class="sidebar-brand-text mx-3" class="brand-image img-circle elevation-3"
           style="opacity: .8">HRM Systems</div>
</a>
<?php endif; ?>


<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
  <a class="nav-link">
    <i class="fas fa-home "></i>
    <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
    <span>Employee Dahboard</span></a>
  
<?php else:?>
  <span>Admin Dashboard</span></a>
  <?php endif; ?>
</li>



<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
    <i class="fas fa-fw fa-folder"></i>
    <span>Pages</span>
  </a>
  <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Pages</h6>
      
      
      <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
 
<?php else:?>

<a class="collapse-item" <?php echo anchor("admin/admin_leaveRequest", 'Leave Requests'); ?></a>
      <a class="collapse-item" <?php echo anchor("admin/admin_view_account_details", 'Account Details'); ?></a>
      
       
 <br>
 <?php endif; ?>
     
    
     
    </div>
  </div>
</li>
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
    <i class="fas fa-envelope fa-fw"></i>
    <span>Inbox</span>
  </a>
  <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Feedback</h6>
      <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
 
<?php else:?>
<a class="collapse-item" <?php echo anchor("admin/admin_reply_messages", 'Messages'); ?></a>
      <?php endif; ?>
      
    </div>
  </div>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
  <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar -->



  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 <!-- Logout Modal-->
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          
          <?php echo anchor("login/logout",'Logout'); ?>
        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="changepassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change Pa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action ="code.php" method ="POST">
      <div class="modal-body">
        <div class ="form-group">
          <label>Enter New Password</label>
          <input type ="text" name ="accountname" class= "form-control" placeholder ="Enter Bank Account Name" readonly>
        </div>
      <div class ="form-group">
          <label>Enter Password Again</label>
          <input type ="text" name ="accountnumber" class= "form-control" placeholder ="Enter Account Number" readonly>
        </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name ="registerbtn" class="btn btn-primary">Submit</button>
      </div>
</form>

    </div>
  </div>
</div>