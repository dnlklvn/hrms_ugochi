<?php 

include('includes/header.php');
include('includes/navbar.php');

?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            

            <!-- Modal -->


            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php if(!empty($user_identity)): ?>
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $user_identity->first_name;?></span>
              <?php else: ?>
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">User</span>

                <?php endif; ?>

                <?php if(!empty($profil_pic)): ?>
                <img class="img-profile rounded-circle" src="<?php echo $profil_pic->avatar; ?>">
                <?php else: ?>

<?php endif; ?>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
    
       
            <div class ="col">
<?php  echo form_open_multipart("employee/addMedicalformDetails/{$result->user_id}",['class' =>'form-horizontal']); ?>
          <?php echo form_hidden('user_id', $result->user_id); ?>
          <?php //echo form_hidden('emp_role_id', $result->user_role_id); ?>
          <!-- Page Heading -->
          <?php //print_r($records); ?>
         <!-- Button trigger modal -->
         <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <a href ="" class ="list-group-item">
       
         <?php if(!empty($profil_pic)): ?>
         <img src="<?php echo $profil_pic->avatar; ?>"style ="width:215px"/>

<?php else: ?>
<img src="<?php echo base_url('resources/img/avatar.png'); ?>"style ="width:215px"/>



<?php endif; ?>



</a>

         <?php echo form_upload(['name' => 'avatar', 'class'=> 'form-control']); ?>
         <?php if(isset($upload_error)) echo $upload_error; ?>
          <br>
<br>
</div>
          </div>
<div class= "row">
        
        <div class ="col">
        <div class="alert alert-danger" role="alert">
<h4 class="alert-heading"></h4>

<?php echo form_error('health_id','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('full_name','<div class ="text-danger">','</div>'); ?>

<?php echo form_error('department','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('mobile_no','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('email_address','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('home_address','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('guardian_name','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('guardian_number','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('genotype','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('blood_group','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('health_complications','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('x_ray_test','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('eye_test','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('urine_test','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('ecg','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('height','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('weight','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('disclaimer','<div class ="text-danger">','</div>'); ?>


<hr>

</div>
</div>
        </div>
<div class="row">

  <div class="col-3">
  <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link active" href="<?php echo base_url("employee/empPersonalDetails/{$result->user_id}"); ?>">Personal Details</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/empContactDetails/{$result->user_id}"); ?>">Contact Details</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/empEmploymentDetails/{$result->user_id}"); ?>">Employment Details</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/empQualificationDetails/{$result->user_id}"); ?>">Qualification Details</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/empMedicalDetails/{$result->user_id}"); ?>">Medical Form</a>
      <br>
      <a class="nav-link active" href="<?php echo base_url("employee/bank_account_details/{$result->user_id}"); ?>">Account Details</a>
      <br>
      <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
  <a class="nav-link active" href="<?php echo base_url("employee/sendMessages/{$result->user_id}"); ?>">Messages</a>
<?php else:?>

 <?php endif; ?>
 <br>
 <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
  <a class="nav-link active" href="<?php echo base_url("employee/leave_request/{$result->user_id}"); ?>">Leave Requests</a>
<?php else:?>

 <?php endif; ?>
 <br>
 <a class="nav-link active" href="<?php echo base_url("employee/upload_documents/{$result->user_id}"); ?>">Upload Documents</a>
 <br>
 <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
  <a class="nav-link active" href="<?php echo base_url("employee/user_change_Password/{$result->user_id}"); ?>">Change Password</a>
<?php else:?>

 <?php endif; ?>
 <br>
    </div>
  </div>
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
      <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
      <form>

      <?php if(!empty($records)): ?>
   <div class="form-group row">
    <label for="inputEmail3" class="col-lg-2 col-form-label">Health ID</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'health_id','class'=>'form-control', 'placeholder'=>' Health ID', 'value' =>set_value('health_id', $records->health_id)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-lg-2 col-form-label">Health ID</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'health_id','class'=>'form-control', 'placeholder'=>' Health ID', 'value' =>set_value('health_id')]); ?>
    </div>
    <?php endif; ?>
  </div>
  

  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Full Name</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'full_name','class'=>'form-control', 'placeholder'=>' full Name', 'value' =>set_value('full_name', $records->full_name)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Full Name</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'full_name','class'=>'form-control', 'placeholder'=>' full Name', 'value' =>set_value('full_name')]); ?>
    </div>
    <?php endif; ?>
  </div>


<!--- hello lastname --->
 
<?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Department</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'department','class'=>'form-control', 'placeholder'=>'Department', 'value' =>set_value('department', $records->department)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Department</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'department','class'=>'form-control', 'placeholder'=>'Department', 'value' =>set_value('department')]); ?>
    </div>
    <?php endif; ?>
  </div>

  <!--- bye last word---->



  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Mobile Number</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'mobile_no','class'=>'form-control', 'placeholder'=>' Mobile Number', 'value' =>set_value('mobile_no', $records->mobile_no )]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Mobile Number</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'mobile_no','class'=>'form-control', 'placeholder'=>' Mobile Number', 'value' =>set_value('mobile_no' )]); ?>
    </div>
    <?php endif; ?>
  </div>



  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Email Address</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'email_address','class'=>'form-control', 'placeholder'=>' Email Address', 'value' =>set_value('email_address', $records->email_address)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Email Address</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'email_address','class'=>'form-control', 'placeholder'=>' Email Address', 'value' =>set_value('email_address')]); ?>
    </div>
    <?php endif; ?>
  </div>


  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">home_address</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'home_address','class'=>'form-control', 'placeholder'=>'home_address', 'value' =>set_value('home_address', $records->home_address)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">home_address</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'home_address','class'=>'form-control', 'placeholder'=>'home_address', 'value' =>set_value('home_address')]); ?>
    </div>
    <?php endif; ?>
  </div>



  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">guardian_name</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'guardian_name','class'=>'form-control', 'placeholder'=>'guardian_name', 'value' =>set_value('guardian_name', $records->guardian_name)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">guardian_name</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'guardian_name','class'=>'form-control', 'placeholder'=>'guardian_name', 'value' =>set_value('guardian_name')]); ?>
    </div>
    <?php endif; ?>
  </div>



  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">guardian_number</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'guardian_number','class'=>'form-control', 'placeholder'=>'guardian_number', 'value' =>set_value('guardian_number', $records->guardian_number)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">guardian_number</label>
    <div class="col-sm-10">
    <?php echo form_input(['name' =>'guardian_number','class'=>'form-control', 'placeholder'=>'guardian_number', 'value' =>set_value('guardian_number')]); ?>
    </div>
    <?php endif; ?>
  </div>



  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Genotype</label>
    <div class="col-sm-10">
    <select class ="form-control" name="genotype">
    <option><?php echo $records->genotype; ?></option>
  
            <option>AA</option>
            <option>AS </option>
            <option>SS  </option>
            <option>AC </option>
            </select>
                        
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Genotype</label>
    <div class="col-sm-10">
    <select class ="form-control" name="genotype">
    <option></option>
  
            <option>AA</option>
            <option>AS </option>
            <option>SS  </option>
            <option>AC </option>
            </select>
                        
    </div>
    <?php endif; ?>
  </div>

  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Blood Group</label>
    <div class="col-sm-4">
    <select class ="form-control" name="blood_group">
    <option><?php echo $records->blood_group; ?></option>
    
    <option>  A RhD positive (A+)</option>
    <option>   A RhD negative (A-)</option>
    <option>   B RhD positive (B+)</option>
    <option>    B RhD negative (B-)</option>
    <option>     O RhD positive (O+)</option>
    <option>      O RhD negative (O-)</option>
    <option>   AB RhD positive (AB+)</option>
    <option>   AB RhD negative (AB-)</option>
           

            </select>
                        
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Blood Group</label>
    <div class="col-sm-4">
    <select class ="form-control" name="blood_group">
    <option></option>
    
    <option>  A RhD positive (A+)</option>
    <option>   A RhD negative (A-)</option>
    <option>   B RhD positive (B+)</option>
    <option>    B RhD negative (B-)</option>
    <option>     O RhD positive (O+)</option>
    <option>      O RhD negative (O-)</option>
    <option>   AB RhD positive (AB+)</option>
    <option>   AB RhD negative (AB-)</option>
           

            </select>
                        
    </div>
    <?php endif; ?>
  </div>







 <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Health Complications</label>
    <div class="col-sm-4">
    <select class ="form-control" name="health_complications">
    <option><?php echo $records->health_complications; ?></option>
    <option>None</option>
            <option>Mild </option>
            <option>Moderate </option>
            <option>Severe </option>
            </select>
                        
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Health Complications</label>
    <div class="col-sm-4">
    <select class ="form-control" name="health_complications">
    <option></option>
    <option>None</option>
            <option>Mild </option>
            <option>Moderate </option>
            <option>Severe </option>
            </select>
                        
    </div>
    <?php endif; ?>
  </div>













  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">ECG /X-ray</label>
    <div class="col-sm-4">
    <select class ="form-control" name="ecg">
    <option><?php echo $records->ecg; ?></option>
    <option>Completed </option>
            <option>Not-Completed</option>

            </select>
                        
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">ECG /Xray</label>
    <div class="col-sm-4">
    <select class ="form-control" name="ecg">
    <option></option>
    <option>Completed </option>
            <option>Not-Completed</option>

            </select>
                        
    </div>
    <?php endif; ?>
  </div>


</div>




<?php if(!empty($records)): ?>
<div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">EYE -TEST </label>
    <div class="col-sm-4">
    <select class ="form-control" name="eye_test">
    <option><?php echo $records->eye_test; ?></option>
    <option>Completed </option>
            <option>Not-Completed</option>

            </select>
                        
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">EYE -TEST </label>
    <div class="col-sm-4">
    <select class ="form-control" name="eye_test">
    <option></option>
    <option>Completed </option>
            <option>Not-Completed</option>

            </select>
                        
    </div>
    <?php endif; ?>
  </div>







  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Urine Test</label>
    <div class="col-sm-4">
     
    <select class ="form-control" name="urine_test">
    <option><?php echo $records->urine_test; ?></option>
    <option>Completed </option>
            <option>Not-Completed</option>

            </select>
                        
    
  </div>
  <!--- bye last word---->
  <?php else: ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Urine Test</label>
    <div class="col-sm-4">
     
    <select class ="form-control" name="urine_test">
    <option></option>
    <option>Completed </option>
            <option>Not-Completed</option>

            </select>
                        
    
  </div>
  <?php endif; ?>
</div>




 
  
     
                </div>
                <?php if(!empty($records)): ?>
                <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">WEIGHT(lb)</label>
    <div class="col-sm-4">
    <?php echo form_input(['name' =>'weight','class'=>'form-control', 'placeholder'=>' WEIGHT(lb)', 'value' =>set_value('weight', $records->weight)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">WEIGHT(lb)</label>
    <div class="col-sm-4">
    <?php echo form_input(['name' =>'weight','class'=>'form-control', 'placeholder'=>' WEIGHT(lb)', 'value' =>set_value('weight')]); ?>
    </div>
    <?php endif; ?>






  <?php if(!empty($records)): ?>
   <div class="form-group row">
    <label for="inputEmail3" class="col-sm-4 col-form-label">Height(lb)</label>
    <div class="col-sm-8">
    <?php echo form_input(['name' =>'height','class'=>'form-control', 'placeholder'=>' Height(lb', 'value' =>set_value('height', $records->height)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-4 col-form-label">Height(lb)</label>
    <div class="col-sm-8">
    <?php echo form_input(['name' =>'height','class'=>'form-control', 'placeholder'=>' Height(lb', 'value' =>set_value('height')]); ?>
    </div>
    <?php endif; ?>


  </div>
  </div>




  <?php if(!empty($records)): ?>
                <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Disclaimer</label>
    <div class="col-sm-10">
     <?php echo form_input(['name' =>'disclaimer','class'=>'form-control', 'placeholder'=>'Disclaimer', 'value' =>set_value('disclaimer', $records->disclaimer)]); ?> 
     Agress to this 
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Disclaimer</label>
    <div class="col-sm-10">
     <?php echo form_input(['name' =>'disclaimer','class'=>'form-control', 'placeholder'=>'Disclaimer', 'value' =>set_value('disclaimer')]); ?> 
     Agress to this 
    </div>
    <?php endif; ?>
  </div>   











  <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
<?php else:?>
  <?php echo form_submit(['value'=> 'Submit', 'class' =>'btn btn-success btn-user btn-block']); ?>
        <?php echo form_reset(['value'=> 'Reset', 'class' =>'btn btn-primary btn-user btn-block']); ?>
 <?php endif; ?>

  <!--- bye last word---->



      </div>
     
    </div>
  </div>
</div>


  </div>

</div>



</div>
<?php echo form_close(); ?>
</div>

            <?php 
  include('includes/footer.php');
include('includes/script.php');


?>
  