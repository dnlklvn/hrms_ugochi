<?php 

include('includes/header.php');
include('includes/navbar.php');

?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            

            <!-- Modal -->


            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php if(!empty($user_identity)): ?>
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $user_identity->first_name;?></span>
              <?php else: ?>
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">User</span>

                <?php endif; ?>

                <?php if(!empty($profil_pic)): ?>
                <img class="img-profile rounded-circle" src="<?php echo $profil_pic->avatar; ?>">
                <?php else: ?>

<?php endif; ?>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
    
       
            <div class ="col">
<?php  echo form_open_multipart("employee/addEmploymentDetails/{$result ->user_id}",['class' =>'form-horizontal']); ?>
          <?php echo form_hidden('user_id', $result->user_id); ?>
          <?php //echo form_hidden('emp_role_id', $result->user_role_id); ?>
          <!-- Page Heading -->
          <?php //print_r($records); ?>
         <!-- Button trigger modal -->
         <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <a href ="" class ="list-group-item">
       
     
         <?php if(!empty($profil_pic)): ?>
         <img src="<?php echo $profil_pic->avatar; ?>"style ="width:215px"/>


         <?php else: ?>
         <img src="<?php echo base_url('resources/img/avatar.png'); ?>"style ="width:215px"/>

         <?php endif; ?>
</a>

         <?php echo form_upload(['name' => 'avatar', 'class'=> 'form-control']); ?>
         <?php if(isset($upload_error)) echo $upload_error; ?>
          <br>
<br>
</div>
          </div>
<div class= "row">
        
        <div class ="col">
        <div class="alert alert-danger" role="alert">
<h4 class="alert-heading"></h4>
<?php echo form_error('category','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('department','<div class ="text-danger">','</div>'); ?>
<?php echo form_error('post','<div class ="text-danger">','</div>'); ?>

<?php echo form_error('date_of_resumption','<div class ="text-danger">','</div>'); ?>
<hr>

</div>
</div>
        </div>
<div class="row">

  <div class="col-3">
  <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link active" href="<?php echo base_url("employee/empPersonalDetails/{$result->user_id}"); ?>">Personal Details</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/empContactDetails/{$result->user_id}"); ?>">Contact Details</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/empEmploymentDetails/{$result->user_id}"); ?>">Employment Details</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/empQualificationDetails/{$result->user_id}"); ?>">Qualification Details</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/empMedicalDetails/{$result->user_id}"); ?>">Medical Form</a>
      <br>
      
      <a class="nav-link active" href="<?php echo base_url("employee/bank_account_details/{$result->user_id}"); ?>">Account Details</a>
      <br>
      <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
  <a class="nav-link active" href="<?php echo base_url("employee/sendMessages/{$result->user_id}"); ?>">Messages</a>
<?php else:?>

<?php endif; ?>
<br>
<a class="nav-link active" href="<?php echo base_url("employee/upload_documents/{$result->user_id}"); ?>">Upload Documents</a>
 <br>
 
 <br>
 <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
  <a class="nav-link active" href="<?php echo base_url("employee/upload_documents/{$result->user_id}"); ?>">Upload Documents</a>
<?php else:?>

 <?php endif; ?>
 <br>
 <?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
  <a class="nav-link active" href="<?php echo base_url("employee/user_change_Password/{$result->user_id}"); ?>">Change Password</a>
<?php else:?>

 <?php endif; ?>
 <br>
    </div>
  </div>
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
      <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
      <form>

      <?php if(!empty($records)): ?>
      <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Categories</label>
    <div class="col-sm-10">
    <select class ="form-control" name="category">
    <option><?php echo $records->category; ?></option>
            <option>None </option>
            <option>Non-Academic </option>
            <option>Academic Staff </option>

            </select>
                        
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Categories</label>
    <div class="col-sm-10">
    <select class ="form-control" name="category">
    <option></option>
            <option>None </option>
            <option>Non-Academic </option>
            <option>Academic Staff </option>

            </select>
                        
    </div>
    <?php endif; ?>
  </div>
  <?php if(!empty($records)): ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Department</label>
    <div class="col-sm-10">
      <?php echo form_input(['name' =>'department','class'=>'form-control', 'placeholder'=>' Department', 'value' =>set_value('department', $records->department )]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Department</label>
    <div class="col-sm-10">
      <?php echo form_input(['name' =>'department','class'=>'form-control', 'placeholder'=>' Department', 'value' =>set_value('department' )]); ?>
    </div>
    <?php endif; ?>
  </div>


<!--- hello lastname --->
<?php if(!empty($records)): ?>
<div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Post</label>
    <div class="col-sm-10">
      <?php echo form_input(['name' =>'post','class'=>'form-control', 'placeholder'=>' Post', 'value' =>set_value('post', $records->post)]); ?>
    </div>
    <?php else: ?>
    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Post</label>
    <div class="col-sm-10">
      <?php echo form_input(['name' =>'post','class'=>'form-control', 'placeholder'=>' Post', 'value' =>set_value('post')]); ?>
    </div>
    <?php endif; ?>
  </div>


  <!--- bye last word---->

  <?php if(!empty($records)): ?>

    <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Date of Resumption</label>
    <div class="col-sm-10">
      <?php echo form_input(['name' =>'date_of_resumption', 'type'=> 'date','class'=>'form-control', 'id' => 'datepicker','placeholder'=>' DOB', 'value' =>set_value('date_of_resumption', $records->date_of_resumption)]); ?>
    </div>
 
  </div>
  <?php else: ?>
  
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Date of Resumption</label>
    <div class="col-sm-10">
      <?php echo form_input(['name' =>'date_of_resumption', 'type'=> 'date','class'=>'form-control', 'id' => 'datepicker','placeholder'=>' DOB', 'value' =>set_value('date_of_resumption')]); ?>
    </div>
 
  </div>
  <?php endif; ?>
  </div>







<!--- hello lastname --->
<?php $sess=$this->session->userdata('loggedIn'); $roleID=$sess['roleID'];?>
  <?php if($roleID>1):?>
<?php else:?>
  <?php echo form_submit(['value'=> 'Submit', 'class' =>'btn btn-success btn-user btn-block']); ?>
        <?php echo form_reset(['value'=> 'Reset', 'class' =>'btn btn-primary btn-user btn-block']); ?>
 <?php endif; ?>

    </div>
  </div>
</div>


  </div>

</div>



</div>
<?php echo form_close(); ?>
</div>
</div>

            <?php 
  include('includes/footer.php');
include('includes/script.php');


?>
  