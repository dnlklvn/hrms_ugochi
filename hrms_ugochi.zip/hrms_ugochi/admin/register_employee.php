<?php 
session_start();
include('includes/header.php');
include('includes/navbar.php');

?>

    
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            

            

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Ugochi</span>
                <img class="img-profile rounded-circle" src="img/avatar04.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
         <!-- Button trigger modal -->

<!-- Modal -->



<!-- Modal -->
<div class="modal fade" id="delete1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Do you want to delete the user employee ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">NO</button>
        <button type="button" class="btn btn-primary">YES</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="messages1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Send Messages</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
  <div class="form-group">
    <label for="exampleFormControlInput1">Email address</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
 <div class="form-group">
    <label for="exampleFormControlInput1">Subject</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Subject">
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Messages</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Send</button>
      </div>
    </div>
  </div>
</div>



<!-- Modal -->
<div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" >Register New Employee</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action ="code.php" method ="POST">
      <div class="modal-body">
        <div class ="row">
        <div class="col-md-4">
        <div class ="form-group" >
          <label>FirstName</label>
          <input type ="text" name ="firstname" class= "form-control" placeholder ="Enter Firstname">
        </div>
</div>
<div class="col-md-4">
        <div class ="form-group" >
          <label>LastName</label>
          <input type ="text" name ="lastname" class= "form-control" placeholder ="Enter LastName">
        </div>
</div>
<div class="col-md-4">
        <div class ="form-group" >
          <label>email</label>
          <input type ="text" name ="email" class= "form-control" placeholder ="Enter Email">
        </div>
</div>

</div>



<div class ="row">
<div class="col-md-4">
        <div class ="form-group" >
          <label>Password</label>
          <input type ="password" name ="password" class= "form-control" placeholder ="Enter password">
        </div>
</div>
        <div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Department</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Non-Academic</option>
      <option>Academic</option>
    </select>
  </div>
</div>
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Position</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Lecturer1</option>
      <option>Leturer2</option>
      <option>Assitant Lecturer</option>
      <option>Others</option>
    </select>
  </div>
</div>

</div>
</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name ="registerbtn" class="btn btn-primary">ADD</button>
      </div>
</form>
    </div>
  </div>
</div>

          
<div class ="container-fluid">
  


<div class ="card shadow mb-4">
  <div class ="card-header py-3">
    <h6 class ="m-0 font-weight-bold text-primary">
    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target=".bd-example-modal-xl">Add New Employee</button>
      
</h6>
</div>

<div class ="card-body">


<?php 
if(isset($_SESSION['success']) && $_SESSION['success'] != ''){
  echo '<h2 class ="alert alert-success "> ' .$_SESSION['success']  .' </h2>';
  unset($_SESSION['success']);

}
if(isset($_SESSION['status']) && $_SESSION['status'] != ''){
  echo '<h2 class ="alert alert-warning"> ' .$_SESSION['status']  .' </h2>';
  unset($_SESSION['status']);
  
}
?>



  <div class ="table-responsive">

  <?php   
  $conn = mysqli_connect("localhost","root","dnlklvn","clearancesystem");
  $query = "SELECT * FROM register_admin";
  $query_run  = mysqli_query($conn, $query);

  ?>
    <table class ="table tabl-bordered" id ="dataTable" width ="100%"cellspacing ="0">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Password</th>
          <th>Edit</th>
          <th>Delete</th>
          <th>Send Message</th>
</tr>
</thead>
<tbody>



 
  <tr> 
  <td>Cedric Kelly</td>
                      <td>Senior Javascript Developer</td>
                      <td>Edinburgh</td>
                      <td>22</td>
    <td>
    <a class="btn btn-primary btn-sm" href="employee_dashboard.php" role="button">VIEW PROFILE</a>
      
  </td>
  <td>
      <button type ="submit" class ="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete1">DELETE</button>
  </td>
  <td>
      <button type ="submit" class ="btn btn-danger btn-sm" data-toggle="modal" data-target="#messages1">SEND MESSAGE</button>
  </td>
  
    
</tr>

</tbody>
</table>


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

</div>


       
  <?php 
  include('includes/footer.php');
include('includes/script.php');


?>

