<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="employee_dashboard.php">
  <div class="simple">
  <img src="img/FUTO_logo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3">
  </div>
  
  <div class="sidebar-brand-text mx-3" class="brand-image img-circle elevation-3"
           style="opacity: .8">HRMS Systems</div>
</a>


<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
  <a class="nav-link" href="employee_dashboard.php">
    <i class="fas fa-home "></i>
    <span>Employee Dashboard</span></a>
</li>
<!-- Modal for Acount details -->

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="accountdetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Account Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
  <div class="form-group">
    <label for="exampleFormControlInput1">Account Name</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Name">
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Account Number</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Number">
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Bank Name </label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Bank Name">
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Sort Number </label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Sort Number">
  </div>
  

</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>

<!-- End Mdal -->
<!-- Modal  -->
<div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" >Enter Bio-Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action ="code.php" method ="POST">
      <div class="modal-body">
        <div class ="row">
        <div class="col-md-4">
        <div class ="form-group" >
          <label>FirstName</label>
          <input type ="text" name ="firstname" class= "form-control" placeholder ="Enter Firstname">
        </div>
</div>
<div class="col-md-4">
        <div class ="form-group" >
          <label>LastName</label>
          <input type ="text" name ="lastname" class= "form-control" placeholder ="Enter LastName">
        </div>
</div>
<div class="col-md-4">
        <div class ="form-group" >
          <label>OtherName</label>
          <input type ="text" name ="othername" class= "form-control" placeholder ="Enter OtherName">
        </div>
</div>

</div>
<div class="text-success d-flex p-2 bd-highlight font-italic">Bio-Data</div>

<div class ="row">
        <div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">State of Origin</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Non-Academic</option>
      <option>Academic</option>
    </select>
  </div>
</div>
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlTextarea1">LCD-A</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
</div>
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Sex</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Male</option>
      <option>Female</option>
      
    </select>
  </div>
</div>
</div>
<div class="text-success d-flex p-2 bd-highlight font-italic">Ensure to enter all details correctly</div>

<div class ="row">
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlTextarea1">Home Address</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
</div>
<div class="col-md-4">
<div class ="form-group" >
          <label>Phone Number1</label>
          <input type ="text" name ="othername" class= "form-control" placeholder ="Enter OtherName">
        </div>
</div>
<div class="col-md-4">
<div class ="form-group" >
          <label>Phone Number2</label>
          <input type ="text" name ="othername" class= "form-control" placeholder ="Enter OtherName">
        </div>
</div>

</div>
<div class ="row">
        
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlSelect1">Religion</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Christianity</option>
      <option>Islam</option>
      <option>Others</option>
      
    </select>
  </div>
</div>
<div class="col-md-4">
<div class ="form-group" >
          <label>Email</label>
          <input type ="email" name ="othername" class= "form-control" placeholder ="Enter Email">
        </div>
</div>
<div class="col-md-4">
<div class ="form-group" >
          <label>ICT NO</label>
          <input type ="email" name ="othername" class= "form-control" placeholder ="Enter ICT Number">
        </div>
</div>

</div>


<div class="text-success d-flex p-2 bd-highlight font-italic">Registration Numbers</div>
<div class ="row">
<div class="col-md-4">
<div class ="form-group" >
          <label>Health Center ID</label>
          <input type ="email" name ="othername" class= "form-control" placeholder ="Enter Health Center Number">
        </div>
</div>
<div class="col-md-4">
        <div class ="form-group" >
          <label>Employment Date</label>
          <input type ="text" name ="lcda" class= "form-control" placeholder ="Enter date">
        </div>
</div>

<div class="col-md-4">
        <div class ="form-group" >
          <label>Library Regr</label>
          <input type ="text" name ="libraryreg" class= "form-control" placeholder ="Enter LIB Reg">
        </div>
</div>
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlSelect1">Marital Status</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Married</option>
      <option>Single</option>
      <option>Divored</option>
      <option>Widowed</option>
      
    </select>
  </div>
</div>
</div>

</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name ="registerbtn" class="btn btn-primary">Submit</button>
      </div>
</form>
    </div>
  </div>
</div>

<!-- Modal  for medica details -->
<div class="modal fade" id="medicaldetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Apply For Leave</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
      <div class="form-group">
    <label for="exampleFormControlInput1">Name</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Name">
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlSelect1">Sex</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Male </option>
      <option>Female</option>
     
      
    </select>
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlSelect1">Blood Group</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Sick Leave</option>
      <option>Maternal Leave</option>
      <option>Others</option>
      
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Genotype</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Sick Leave</option>
      <option>Maternal Leave</option>
      <option>Others</option>
      
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">HIV Status</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Sick Leave</option>
      <option>Maternal Leave</option>
      <option>Others</option>
      
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Any Health Issues</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->


<!-- Modal  for leave-->
<div class="modal fade" id="leaveapply" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Apply For Leave</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
      <div class="form-group">
    <label for="exampleFormControlInput1">Name</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Name">
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Email address</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Reasons</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Sick Leave</option>
      <option>Maternal Leave</option>
      <option>Others</option>
      
    </select>
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Enter More Details(Others)</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Apply</button>
      </div>
    </div>
  </div>
</div>

<!-- MODAL END-->

<!-- Modal  for submit-->
<div class="modal fade" id="submitdoc" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Submit Your Documents</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
  <div class="form-group">
    <label for="exampleFormControlFile1">Upload Nysc Certificate</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>

  <div class="form-group">
    <label for="exampleFormControlFile1">Upload Birth Certificate</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
  <div class="form-group">
    <label for="exampleFormControlFile1">Upload Jamb Certificate</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlFile1">Upload O'Level Certificate</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
  <div class="form-group">
    <label for="exampleFormControlFile1">Drivers License(*Optional)</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
  <div class="form-group">
    <label for="exampleFormControlFile1">Higher Institution Certificate</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Upload</button>
      </div>
    </div>
  </div>
</div>

<!-- MODAL END-->
<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
    <i class="fas fa-fw fa-folder"></i>
    <span>Pages</span>
  </a>
  <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Pages</h6>
      
      <a class="collapse-item" data-toggle="modal" data-toggle="modal" data-target=".bd-example-modal-xl">Bio Data</a>

     
      <a class="collapse-item" data-toggle="modal" data-target="#leaveapply">Apply For Leave</a>
      <a class="collapse-item" data-toggle="modal" data-target="#accountdetails">Bank Account Details</a>
      <a class="collapse-item" data-toggle="modal" data-target="#medicaldetails">Medical Details</a>
      <a class="collapse-item" data-toggle="modal" data-target="#submitdoc">Uploads</a>
    </div>
  </div>
</li>
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
    <i class="fas fa-envelope fa-fw"></i>
    <span>Inbox</span>
  </a>
  <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Feedback</h6>
      
      <a class="collapse-item" href="messages.php">View Messages</a>
      
    </div>
  </div>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
  <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar -->



  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 <!-- Logout Modal-->
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>
