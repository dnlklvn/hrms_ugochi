<?php
session_start();

$conn = mysqli_connect("localhost","root","dnlklvn","clearancesystem");


if(isset($_POST['registerbtn'])){

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];

if($password === $cpassword)
{
    $query = "INSERT INTO register_admin(username,email,password) VALUES ('$username','$email','$password')";
    $query_run = mysqli_query($conn ,$query);


    if($query_run){
        $_SESSION['success'] = "Admin Profile Added";
        header('Location: register_admin.php');

    }else{
        $_SESSION['status'] = "Admin Profile NOT Added";
        header('Location: register_admin.php');

    }
    
}
else{
        $_SESSION['status'] = "Passwords Does Not Match";
        header('Location: register_admin.php');

    }
}
   



?>