<?php 
session_start();
include('includes/header.php');
include('includes/navbar.php');

?>

    
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            

            

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Valerie Luna</span>
                <img class="img-profile rounded-circle" src="img/avatar04.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
         <!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="addadmin" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Register New Employee</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action ="code.php" method ="POST">
      <div class="modal-body">
        <div class ="form-group">
          <label>Username</label>
          <input type ="text" name ="username" class= "form-control" placeholder ="Enter Username">
        </div>
      <div class ="form-group">
          <label>Email</label>
          <input type ="email" name ="email" class= "form-control" placeholder ="Enter Email">
        </div>
        <div class ="form-group">
          <label>Password</label>
          <input type ="password" name ="password" class= "form-control" placeholder ="Enter Password">
        </div>
        <div class ="form-group">
          <label>Confirm Password</label>
          <input type ="password" name ="confirmpassword" class= "form-control" placeholder ="Enter Password">
        </div>
        <div class="form-group">
    <label for="exampleFormControlFile1">Upload Image avatar</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name ="registerbtn" class="btn btn-primary">Save</button>
      </div>
</form>

    </div>
  </div>
</div>
          
<div class ="container-fluid">
  


<div class ="card shadow mb-4">
  <div class ="card-header py-3">
    <h6 class ="m-0 font-weight-bold text-primary">
      <button type ="button" class ="btn btn-primary" data-toggle ="modal" data-target ="#addadmin">
        Add New Employee

</button>
</h6>
</div>

<div class ="card-body">


<?php 
if(isset($_SESSION['success']) && $_SESSION['success'] != ''){
  echo '<h2 class ="alert alert-success "> ' .$_SESSION['success']  .' </h2>';
  unset($_SESSION['success']);

}
if(isset($_SESSION['status']) && $_SESSION['status'] != ''){
  echo '<h2 class ="alert alert-warning"> ' .$_SESSION['status']  .' </h2>';
  unset($_SESSION['status']);
  
}
?>



  <div class ="table-responsive">

  <?php   
  $conn = mysqli_connect("localhost","root","dnlklvn","clearancesystem");
  $query = "SELECT * FROM register_admin";
  $query_run  = mysqli_query($conn, $query);

  ?>
    <table class ="table tabl-bordered" id ="dataTable" width ="100%"cellspacing ="0">
      <thead>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Email</th>
          <th>Password</th>
          <th>Edit</th>
          <th>Delete</tr>
</tr>
</thead>
<tbody>

<?php
      if(mysqli_num_rows($query_run)> 0)
{
      while($row = mysqli_fetch_assoc($query_run))
  {
 ?>

 
  <tr> 
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['password']; ?></td>
    <td>
      <button type ="submit" class ="btn btn-success">EDIT</button>
  </td>
  <td>
      <button type ="submit" class ="btn btn-danger">DELETE</button>
  </td>
  
    
</tr>
<?php

 
  }
}else{
  echo "No Record found";
}


?>
</tbody>
</table>


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

</div>


       
  <?php 
  include('includes/footer.php');
include('includes/script.php');


?>

