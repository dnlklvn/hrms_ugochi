<?php 
session_start();
include('includes/header.php');
include('includes/navbar.php');

?>

    
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            

            

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Ugochi</span>
                <img class="img-profile rounded-circle" src="img/avatar04.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
         <!-- Button trigger modal -->

<!-- Modal -->

<div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" >Register New Employee</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action ="code.php" method ="POST">
      <div class="modal-body">
        <div class ="row">
        <div class="col-md-4">
        <div class ="form-group" >
          <label>FirstName</label>
          <input type ="text" name ="firstname" class= "form-control" placeholder ="Enter Firstname">
        </div>
</div>
<div class="col-md-4">
        <div class ="form-group" >
          <label>LastName</label>
          <input type ="text" name ="lastname" class= "form-control" placeholder ="Enter LastName">
        </div>
</div>
<div class="col-md-4">
        <div class ="form-group" >
          <label>OtherName</label>
          <input type ="text" name ="othername" class= "form-control" placeholder ="Enter OtherName">
        </div>
</div>

</div>
<div class="text-success d-flex p-2 bd-highlight font-italic">Employment Category</div>

<div class ="row">
        <div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Category</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Non-Academic</option>
      <option>Academic</option>
    </select>
  </div>
</div>
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Position</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Lecturer1</option>
      <option>Leturer2</option>
      <option>Assitant Lecturer</option>
      <option>Others</option>
    </select>
  </div>
</div>
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Sex</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Male</option>
      <option>Female</option>
      
    </select>
  </div>
</div>
</div>
<div class="text-success d-flex p-2 bd-highlight font-italic">Qualification</div>

<div class ="row">
        <div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">O'Level</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>WAEC</option>
      <option>NECO</option>
      <option>GCE</option>
    </select>
  </div>
</div>
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlFile1">Upload O'level Result</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
</div>
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Tertiary Education</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Ordinary National Diploma</option>
      <option>Higher Natinal Diploma</option>
      <option>Bsc</option>
      <option>Msc</option>
      <option>PHD</option>
      <option>Bsc and Msc</option>
      <option>Bsc and PHD and Msc</option>
      
    </select>
  </div>
</div>

</div>
<div class ="row">
        
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlFile1">Upload Result</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
</div>
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlFile1">Upload Birth Certificate</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
</div>
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlFile1">Upload CV</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
</div>

</div>


<div class="text-success d-flex p-2 bd-highlight font-italic">Bio-data</div>
<div class ="row">
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">State Of Origin</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Ordinary National Diploma</option>
      <option>Higher Natinal Diploma</option>
      <option>Bsc</option>
      <option>Msc</option>
      <option>PHD</option>
      <option>Bsc and Msc</option>
      <option>Bsc and PHD and Msc</option>
      
    </select>
  </div>
</div>
<div class="col-md-4">
        <div class ="form-group" >
          <label>Local Government</label>
          <input type ="text" name ="lcda" class= "form-control" placeholder ="Enter LocalGovenment">
        </div>
</div>

<div class="col-md-4">
        <div class ="form-group" >
          <label>Mobile Number</label>
          <input type ="text" name ="homeaddress" class= "form-control" placeholder ="Enter Mobile Number">
        </div>
</div>
</div>
<div class ="row">
<div class="col-md-4">
<div class="form-group">
    <label for="exampleFormControlTextarea1">Home Address</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
</div>


</div>

<div class="text-success d-flex p-2 bd-highlight font-italic">Health-Center Details</div>
<div class ="row">
<div class="col-md-4">
        <div class ="form-group" >
          <label>Health Center ID</label>
          <input type ="text" name ="homeaddress" class= "form-control" placeholder ="Enter HealthCenter ID">
        </div>
</div>
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Genotype</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Ordinary National Diploma</option>
      <option>Higher Natinal Diploma</option>
      <option>Bsc</option>
      <option>Msc</option>
      <option>PHD</option>
      <option>Bsc and Msc</option>
      <option>Bsc and PHD and Msc</option>
      
    </select>
  </div>
</div>
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Blood Group</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Ordinary National Diploma</option>
      <option>Higher Natinal Diploma</option>
      <option>Bsc</option>
      <option>Msc</option>
      <option>PHD</option>
      <option>Bsc and Msc</option>
      <option>Bsc and PHD and Msc</option>
      
    </select>
  </div>
 
</div>
</div>
<div class="text-success d-flex p-2 bd-highlight font-italic">Library Details</div>
<div class ="row">
<div class="col-md-4">
        <div class ="form-group" >
          <label>Library ID</label>
          <input type ="text" name ="homeaddress" class= "form-control" placeholder ="Enter HealthCenter ID">
        </div>
</div>

<div class="col-md-4">
<div class="text-success d-flex p-2 bd-highlight font-italic">Salary</div>
        <div class="form-group">
   
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Ordinary National Diploma</option>
      <option>Higher Natinal Diploma</option>
      <option>Bsc</option>
      <option>Msc</option>
      <option>PHD</option>
      <option>Bsc and Msc</option>
      <option>Bsc and PHD and Msc</option>
      
    </select>
  </div>
</div>
<div class="col-md-4">
        <div class="form-group">
    <label for="exampleFormControlSelect1">Date of Employment</label>
    <select class="form-control" id="exampleFormControlSelect1">
    <option>Select</option>
      <option>Ordinary National Diploma</option>
      <option>Higher Natinal Diploma</option>
      <option>Bsc</option>
      <option>Msc</option>
      <option>PHD</option>
      <option>Bsc and Msc</option>
      <option>Bsc and PHD and Msc</option>
      
    </select>
  </div>
 
</div>
</div>
</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name ="registerbtn" class="btn btn-primary">ADD</button>
      </div>
</form>
    </div>
  </div>
</div>

          
<div class ="container-fluid">
  


<div class ="card shadow mb-4">
  <div class ="card-header py-3">
    <h6 class ="m-0 font-weight-bold text-primary">
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-xl">Add New Employee</button>
      
</h6>
</div>

<div class ="card-body">


<?php 
if(isset($_SESSION['success']) && $_SESSION['success'] != ''){
  echo '<h2 class ="alert alert-success "> ' .$_SESSION['success']  .' </h2>';
  unset($_SESSION['success']);

}
if(isset($_SESSION['status']) && $_SESSION['status'] != ''){
  echo '<h2 class ="alert alert-warning"> ' .$_SESSION['status']  .' </h2>';
  unset($_SESSION['status']);
  
}
?>



  <div class ="table-responsive">

  <?php   
  $conn = mysqli_connect("localhost","root","dnlklvn","clearancesystem");
  $query = "SELECT * FROM register_admin";
  $query_run  = mysqli_query($conn, $query);

  ?>
    <table class ="table tabl-bordered" id ="dataTable" width ="100%"cellspacing ="0">
      <thead>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Email</th>
          <th>Password</th>
          <th>Edit</th>
          <th>Delete</tr>
</tr>
</thead>
<tbody>

<?php
      if(mysqli_num_rows($query_run)> 0)
{
      while($row = mysqli_fetch_assoc($query_run))
  {
 ?>

 
  <tr> 
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['password']; ?></td>
    <td>
      <button type ="submit" class ="btn btn-success btn-sm" >EDIT</button>
  </td>
  <td>
      <button type ="submit" class ="btn btn-danger btn-sm">DELETE</button>
  </td>
  
    
</tr>
<?php

 
  }
}else{
  echo "No Record found";
}


?>
</tbody>
</table>


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

</div>


       
  <?php 
  include('includes/footer.php');
include('includes/script.php');


?>

