<?php 
session_start();
include('includes/header.php');
include('includes/navbar.php');

?>

    
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            

            

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Ugochi</span>
                <img class="img-profile rounded-circle" src="img/avatar04.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
         <!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="addadmin" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Leave Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action ="code.php" method ="POST">
      <div class="modal-body">
        <div class ="form-group">
          <label>Name</label>
          <input type ="text" name ="username" class= "form-control" placeholder ="Enter Username" readonly>
        </div>
      <div class ="form-group">
          <label>Email</label>
          <input type ="email" name ="email" class= "form-control" placeholder ="Enter Email" readonly>
        </div>
        <div class ="form-group">
          <label>Position</label>
          <input type ="text" name ="position" class= "form-control" placeholder ="Enter Post" readonly>
        </div>
        <div class ="form-group">
          <label>Office</label>
          <input type ="text" name ="position" class= "form-control" placeholder ="Enter Post" readonly>
        </div>
        <div class="form-group">
    <label >Reason</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" readonly></textarea>
  </div>
  <fieldset class="form-group">
    <div class="row">
      <legend class="col-form-label col-sm-2 pt-0">Leave Status</legend>
      <div class="col-sm-10">
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
          <label class="form-check-label" for="gridRadios1">
            Approve
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
          <label class="form-check-label" for="gridRadios2">
            Dissapprove
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
          <label class="form-check-label" for="gridRadios2">
            Hold
          </label>
        </div>
      </div>
    </div>
  </fieldset>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name ="registerbtn" class="btn btn-primary">Save</button>
      </div>
</form>

    </div>
  </div>
</div>
          
<div class ="container-fluid">
  

 <!-- DataTales Example -->
 <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Leave Request</h6>
             
            </div>
            
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                        <th>#</th>
                      <th>Name</th>
                      <th>Position</th>
                      <th>Office</th>
                      <th>Reason</th>
                      <th>View</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                    <th>#</th>
                      <th>Name</th>
                      <th>Position</th>
                      <th>Office</th>
                      <th>Reason</th>
                      <th>View</th>
                    <th>Status</tr>
                    </tr>
                  </tfoot>
                  <tbody>
                    <tr>
                        <td>1</td>
                      <td>Tiger Nixon</td>
                      <td>System Architect</td>
                      <td>Edinburgh</td>
                      <td>61</td>
                      <td>
      <button type ="submit" class ="btn btn-success btn-sm" data-toggle="modal" data-target="#addadmin">EDIT</button>
  </td>
  <td>
      <button type ="submit" href="#" class="btn btn-danger btn-circle btn-sm">
                    <i class="fas fa-null"></i>
                  </a> </button>
  </td>
                    </tr>
                    <tr>
                        <td>1</td>
                      <td>Tiger Nixon</td>
                      <td>System Architect</td>
                      <td>Edinburgh</td>
                      <td>61</td>
                      <td>
      <button type ="submit" class ="btn btn-success btn-sm" data-toggle="modal" data-target="#addadmin">EDIT</button>
  </td>
  <td>
      <button type ="submit" href="#" class="btn btn-warning btn-circle btn-sm">
                    <i class="fas fa-exclamation-triangle"></i>
                  </a> </button>
  </td>
                    </tr> <tr>
                        <td>1</td>
                      <td>Tiger Nixon</td>
                      <td>System Architect</td>
                      <td>Edinburgh</td>
                      <td>61</td>
                      <td>
      <button type ="submit" class ="btn btn-success btn-sm" data-toggle="modal" data-target="#addadmin">EDIT</button>
  </td>
  <td>
      <button type ="submit" href="#" class="btn btn-danger btn-circle btn-sm">
                    <i class="fas fa-null"></i>
                  </a> </button>
  </td>
                    </tr>
                    
                    <tr>
                        <td>1</td>
                      <td>Tiger Nixon</td>
                      <td>System Architect</td>
                      <td>Edinburgh</td>
                      <td>61</td>
                      <td>
      <button type ="submit" class ="btn btn-success btn-sm" data-toggle="modal" data-target="#addadmin">EDIT</button>
  </td>
  <td>
      <button type ="submit" href="#" class="btn btn-success btn-circle btn-sm">
                    <i class="fas fa-check"></i>
                  </a> </button>
  </td>
                    </tr>
                    <tr>
                        <td>1</td>
                      <td>Tiger Nixon</td>
                      <td>System Architect</td>
                      <td>Edinburgh</td>
                      <td>61</td>
                      <td>
      <button type ="submit" class ="btn btn-success btn-sm" data-toggle="modal" data-target="#addadmin">EDIT</button>
  </td>
  <td>
      <button type ="submit" href="#" class="btn btn-success btn-circle btn-sm">
                    <i class="fas fa-check"></i>
                  </a> </button>
  </td>
                    </tr>
                    
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>




            <?php 
  include('includes/footer.php');
include('includes/script.php');


?>
